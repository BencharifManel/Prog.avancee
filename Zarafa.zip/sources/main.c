#include "../headers/prototypes.h"
#include "../headers//audio.h"

// D�claration des variables / structures utilis�es par le jeu
Input input;


int main(){
    unsigned int frameLimit = SDL_GetTicks() + 16;
    int go;

    // Initialisation de la SDL
    init("ZARAFA");

    // Initialisation de l'Audio
    initAudio();

    // Musique du jeu
    playMusic("../audio/melody.wav", 10);

    // Chargement des ressources (graphismes, sons)
    loadGame();

    // On initialise le joueur
    initializePlayer();

    // Appelle la fonction cleanup � la fin du programme
    atexit(cleanup);

    go = 1;

    // Boucle infinie, principale, du jeu
    while (go == 1){
        //Gestion des inputs clavier
        getInput(&input);

        //On dessine le menu
        drawMenu(&input);

        //Si on clique sur jouer
        while(input.jouer == 1){
            getInput(&input);

            // On met � jour et on dessine le jeu
            updatePlayer(&input);
            drawGame();
        }

        // 60 fps
        delay(frameLimit);
        frameLimit = SDL_GetTicks() + 16;
    }

    // On quitte
    exit(0);
}
