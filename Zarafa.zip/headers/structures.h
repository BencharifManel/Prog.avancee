#ifndef STRUCTURES
#define STRUCTURES

#include "param.h"

//*** Les structures seront regroup�es ici ***

//Input : g�rer le clavier
typedef struct Input{

    int left, right, jump, jouer, perdu, gagne, pause;

} Input;

//Map : g�rer la map
typedef struct Map{

    SDL_Texture *background;
    SDL_Texture *tileSet;

    // Tableau contenant les infos du fichier
    char tile[MAP_Y][MAP_X];

} Map;

// Structure pour g�rer nos sprites
typedef struct GameObject{
    // Coordonn�es
    int x, y;

    // Taille
    int h, w;

    // Pour l'animation
    int frameNumber, frameTimer, frameMax;

    int etat, direction;

    //s'il est vivant/mort
    int alive;
    //s'il est sur le sol
    int onGround, timerSaut;

    //Pour le score
    int score;

} GameObject;

#endif
